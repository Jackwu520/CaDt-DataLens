from windows_mcp.desktop.utils import (
    as_bool,
    resolve_known_folder_guid_path,
)
from windows_mcp.powershell.utils import ps_quote
from windows_mcp.powershell import PowerShellExecutor
from windows_mcp.vdm.core import (
    get_all_desktops,
    get_current_desktop,
    is_window_on_current_desktop,
)
from windows_mcp.desktop.views import DesktopState, Window, Browser, Status, Size, Display
from windows_mcp.tree.views import BoundingBox, TreeElementNode, TreeState, SemanticNode
from PIL import ImageFont, ImageDraw, Image
from windows_mcp.tree.service import Tree, _excluded_process_names, _window_process_name
from windows_mcp.desktop import screenshot as screenshot_capture
from windows_mcp.desktop.control import get_controller
from windows_mcp.desktop import flash_overlay
from windows_mcp.infrastructure import safe_get
from windows_mcp.desktop import control_overlay
from urllib.parse import urljoin
from locale import getpreferredencoding
from typing import Literal
from markdownify import markdownify
from fuzzywuzzy import process
from time import sleep, time, perf_counter
from psutil import Process
import math
import win32process
import win32gui
import win32con
import requests
import logging
import random
import ctypes
import csv
import re
import os
import io

logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)

import windows_mcp.uia as uia  # noqa: E402

# Key name aliases for shortcut keys that differ from UIA SpecialKeyNames
_KEY_ALIASES = {
    "backspace": "Back",
    "capslock": "Capital",
    "scrolllock": "Scroll",
    "windows": "Win",
    "command": "Win",
    "option": "Alt",
    # Natural names for punctuation keys (US layout).
    "comma": ",",
    "period": ".",
    "dot": ".",
    "minus": "-",
    "dash": "-",
    "hyphen": "-",
    "equal": "=",
    "equals": "=",
    # "+" itself needs Shift and would be typed as a Unicode packet, not a key chord;
    # the "=/+" key is what apps bind for Ctrl+Plus (zoom in).
    "plus": "=",
    "semicolon": ";",
    "slash": "/",
    "backslash": "\\",
    "grave": "`",
    "backtick": "`",
    "bracketleft": "[",
    "lbracket": "[",
    "bracketright": "]",
    "rbracket": "]",
    "apostrophe": "'",
    "quote": "'",
}

# Characters with a meaning in SendKeys syntax; they must be braced to be literal.
_SENDKEYS_SYNTAX_CHARS = set("{}()")

# Scrape converts only these to Markdown; any other body is returned as fetched.
_HTML_MEDIA_TYPES = frozenset({"text/html", "application/xhtml+xml"})


def _shortcut_to_sendkeys(shortcut: str) -> str:
    """Translate "ctrl+shift+comma" style input into a SendKeys string.

    Natural names such as "comma" or "bracketleft" map to their character, and
    SendKeys syntax characters are braced so "alt+(" is a key, not a group.
    Raises ValueError for empty parts (e.g. "ctrl++"; use "plus") so nothing is
    pressed. Unknown multi-character names are rejected by SendKeys itself before
    any input is sent.
    """
    parts = [part.strip() for part in shortcut.split("+")]
    if not shortcut.strip() or any(not part for part in parts):
        raise ValueError(
            f"Invalid shortcut {shortcut!r}: empty key name. "
            'Use names such as "plus", "comma", "minus" for punctuation keys.'
        )
    sendkeys_str = ""
    for key in parts:
        name = _KEY_ALIASES.get(key.lower(), key)
        if len(name) == 1:
            sendkeys_str += "{" + name + "}" if name in _SENDKEYS_SYNTAX_CHARS else name
        else:
            sendkeys_str += "{" + name + "}"
    return sendkeys_str


def _snapshot_profile_enabled() -> bool:
    value = os.getenv("WINDOWS_MCP_PROFILE_SNAPSHOT", "")
    return value.strip().lower() in {"1", "true", "yes", "on"}


def _escape_text_for_sendkeys(text: str) -> str:
    """Escape special characters so uia.SendKeys types them correctly."""
    result = []
    for ch in text:
        if ch == "{":
            result.append("{{}")
        elif ch == "}":
            result.append("{}}")
        elif ch == "\n":
            result.append("{Enter}")
        elif ch == "\t":
            result.append("{Tab}")
        elif ch == "\r":
            continue
        else:
            result.append(ch)
    return "".join(result)


class Desktop:
    def __init__(self):
        self.encoding = getpreferredencoding()
        self.tree = Tree(self)
        self.desktop_state = None

    def get_state(
        self,
        use_annotation: bool | str = True,
        use_vision: bool | str = False,
        use_dom: bool | str = False,
        use_ui_tree: bool | str = True,
        as_bytes: bool | str = False,
        scale: float = 1.0,
        grid_lines: tuple[int, int] | None = None,
        display_indices: list[int] | None = None,
        region: list[int] | tuple[int, ...] | None = None,
        max_image_size: Size | None = None,
        window_filter: str | None = None,
    ) -> DesktopState:
        use_annotation = use_annotation is True or (
            isinstance(use_annotation, str) and use_annotation.lower() == "true"
        )
        use_vision = use_vision is True or (
            isinstance(use_vision, str) and use_vision.lower() == "true"
        )
        use_dom = use_dom is True or (isinstance(use_dom, str) and use_dom.lower() == "true")
        use_ui_tree = use_ui_tree is True or (
            isinstance(use_ui_tree, str) and use_ui_tree.lower() == "true"
        )
        as_bytes = as_bytes is True or (isinstance(as_bytes, str) and as_bytes.lower() == "true")

        if use_dom and not use_ui_tree:
            raise ValueError("use_dom=True requires use_ui_tree=True")

        start_time = time()
        profile_enabled = _snapshot_profile_enabled()
        profile_started_at = perf_counter()
        stage_started_at = profile_started_at
        desktop_context_ms = 0.0
        tree_capture_ms = 0.0
        region_filter_ms = 0.0
        screenshot_capture_ms = 0.0
        screenshot_resize_ms = 0.0
        state_build_ms = 0.0
        displays = self.get_displays()
        available_displays = [self._display_to_view(display) for display in displays]
        region_rect = self.parse_region_selection(region)
        capture_rect = (
            region_rect
            if region_rect is not None
            else (
                self.get_display_union_rect(display_indices, displays) if display_indices else None
            )
        )
        screenshot_region = self._rect_to_bounding_box(capture_rect) if capture_rect else None

        # Fast path for Screenshot tool (use_ui_tree=False): skip window enumeration.
        # UIAutomation calls (get_controls_handles / get_windows / get_active_window)
        # can hang when an app is launching and not responding to WM messages.
        if use_ui_tree:
            controls_handles = self.get_controls_handles()  # Taskbar,Program Manager,Apps, Dialogs
            windows, windows_handles = self.get_windows(controls_handles=controls_handles)  # Apps
            active_window = self.get_active_window(windows=windows)  # Active Window
            active_window_handle = active_window.handle if active_window else None
        else:
            controls_handles = []
            windows = []
            windows_handles = set()
            active_window = None
            active_window_handle = None

        try:
            active_desktop = get_current_desktop()
            all_desktops = get_all_desktops()
        except Exception:
            # The virtual desktop calls raise COMError, not RuntimeError, for example after
            # explorer.exe restarts. Report the default desktop instead of failing the capture.
            logger.warning("Could not read the virtual desktops", exc_info=True)
            active_desktop = {
                "id": "00000000-0000-0000-0000-000000000000",
                "name": "Default Desktop",
            }
            all_desktops = [active_desktop]

        if active_window is not None and active_window in windows:
            windows.remove(active_window)

        # --- 本地补丁（0.8.9+p1）：按窗口标题过滤树与截图 -------------------------
        # 上游只能按显示器 / 矩形裁剪。同时开着几十个窗口时，无关窗口的元素会先把
        # 元素预算（默认 500 条）吃满，真正想看的那个窗口反而被截断——实测点一个
        # 卡片要翻好几屏才找到。这里先按标题正则挑出目标窗口，只对它建树，并把
        # 截图裁到它的矩形（显式传了 region 时以 region 为准）。
        window_filter_applied = False
        if window_filter and use_ui_tree:
            try:
                pattern = re.compile(window_filter, re.IGNORECASE)
            except re.error as exc:
                raise ValueError(
                    f"window 不是合法的正则表达式：{window_filter}（{exc}）"
                ) from exc
            candidates = [active_window] if active_window is not None else []
            candidates.extend(windows)
            matched = [w for w in candidates if w is not None and pattern.search(w.name or "")]
            if not matched:
                raise ValueError(
                    f"没有标题匹配 {window_filter!r} 的窗口；先调 Snapshot() 看当前窗口列表"
                )
            target = matched[0]
            active_window = target
            active_window_handle = target.handle
            windows = [w for w in matched[1:]]
            windows_handles = {w.handle for w in windows}
            window_filter_applied = True
            # 没显式给 region 时把截图裁到目标窗口：元素编号与截图坐标系才对得上
            if region_rect is None:
                capture_rect = target.bounding_box
                screenshot_region = self._rect_to_bounding_box(capture_rect)

        if profile_enabled:
            desktop_context_ms = (perf_counter() - stage_started_at) * 1000
            stage_started_at = perf_counter()

        logger.debug(f"Active window: {active_window or 'No Active Window Found'}")
        logger.debug(f"Windows: {windows}")

        if use_ui_tree:
            other_windows_handles = set(controls_handles) - windows_handles
            if active_window_handle is not None:
                other_windows_handles.discard(active_window_handle)
            tree_active_window_handle = active_window_handle
            if screenshot_region:
                active_window_in_region = (
                    self._filter_window_to_region(active_window, screenshot_region) is not None
                )
                tree_active_window_handle = (
                    active_window_handle if active_window_in_region else None
                )
                other_windows_handles.update(
                    window.handle
                    for window in windows
                    if self._filter_window_to_region(window, screenshot_region) is not None
                )
            # controls_handles is in z-order, front first. Keep that order: the tree walks the
            # windows in the order given and skips the rest once the element limit is reached.
            if window_filter_applied:
                # 只保留目标窗口：controls_handles 含任务栏/桌面等全部句柄，
                # 按它算差集会把无关窗口又带回树里。
                other_windows_handles = {w.handle for w in windows}
                tree_active_window_handle = active_window_handle
            z_order = {handle: index for index, handle in enumerate(controls_handles)}
            tree_state = self.tree.get_state(
                tree_active_window_handle,
                sorted(other_windows_handles, key=lambda h: z_order.get(h, len(z_order))),
                use_dom=use_dom,
            )
        else:
            root_box = screenshot_region or self.tree.screen_box
            tree_state = TreeState(
                status=True,
                root_node=TreeElementNode(
                    name="Desktop",
                    control_type="PaneControl",
                    bounding_box=root_box,
                    center=root_box.get_center(),
                    window_name="Desktop",
                    metadata={},
                ),
            )

        if profile_enabled:
            tree_capture_ms = (perf_counter() - stage_started_at) * 1000
            stage_started_at = perf_counter()

        if screenshot_region:
            active_window = self._filter_window_to_region(active_window, screenshot_region)
            windows = self._filter_windows_to_region(windows, screenshot_region)
            if use_ui_tree:
                tree_state = self._filter_tree_state_to_region(tree_state, screenshot_region)

        # Desktop queries and UI tree traversal can be slow. Sample the cursor
        # afterwards to keep the metadata and annotation close to capture time.
        cursor_position = self.get_cursor_location()
        if screenshot_region and not self._point_in_region(cursor_position, screenshot_region):
            cursor_position = None

        if profile_enabled:
            region_filter_ms = (perf_counter() - stage_started_at) * 1000
            stage_started_at = perf_counter()

        screenshot_original_size = None
        applied_scale = None
        if use_vision:
            if use_annotation:
                nodes = tree_state.interactive_nodes
                screenshot = self.get_annotated_screenshot(
                    nodes=nodes,
                    cursor_pos=cursor_position,
                    grid_lines=grid_lines,
                    capture_rect=capture_rect,
                )
            else:
                screenshot = self.get_screenshot(capture_rect=capture_rect)
                if grid_lines:
                    # use_annotation=False leaves out the element boxes, not a requested grid.
                    screenshot = screenshot.copy()
                    self._draw_grid_lines(screenshot, grid_lines)

            screenshot_original_size = Size(width=screenshot.width, height=screenshot.height)

            if profile_enabled:
                screenshot_capture_ms = (perf_counter() - stage_started_at) * 1000
                stage_started_at = perf_counter()

            if max_image_size:
                scale_width = (
                    max_image_size.width / screenshot.width
                    if screenshot.width > max_image_size.width
                    else 1.0
                )
                scale_height = (
                    max_image_size.height / screenshot.height
                    if screenshot.height > max_image_size.height
                    else 1.0
                )
                scale = min(scale, scale_width, scale_height)

            applied_scale = scale
            if scale != 1.0:
                screenshot = screenshot.resize(
                    (int(screenshot.width * scale), int(screenshot.height * scale)),
                    Image.LANCZOS,
                )

            if profile_enabled:
                screenshot_resize_ms = (perf_counter() - stage_started_at) * 1000
                stage_started_at = perf_counter()

            if as_bytes:
                buffered = io.BytesIO()
                screenshot.save(buffered, format="PNG", optimize=True, compress_level=6)
                screenshot = buffered.getvalue()
                buffered.close()
        else:
            screenshot = None

        self.desktop_state = DesktopState(
            active_window=active_window,
            windows=windows,
            active_desktop=active_desktop,
            all_desktops=all_desktops,
            screenshot=screenshot,
            cursor_position=cursor_position,
            screenshot_original_size=screenshot_original_size,
            screenshot_scale=applied_scale,
            screenshot_region=screenshot_region,
            screenshot_displays=display_indices,
            available_displays=available_displays,
            tree_state=tree_state,
            screenshot_backend=getattr(self, "_last_screenshot_backend", None)
            if use_vision
            else None,
            capture_sec=time() - start_time,
        )
        if profile_enabled:
            state_build_ms = (perf_counter() - stage_started_at) * 1000
            total_profile_ms = (perf_counter() - profile_started_at) * 1000
            logger.info(
                "Snapshot profile: desktop_context_ms=%.1f tree_capture_ms=%.1f region_filter_ms=%.1f screenshot_capture_ms=%.1f screenshot_resize_ms=%.1f state_build_ms=%.1f total_ms=%.1f use_vision=%s use_dom=%s use_ui_tree=%s use_annotation=%s displays=%s",
                desktop_context_ms,
                tree_capture_ms,
                region_filter_ms,
                screenshot_capture_ms,
                screenshot_resize_ms,
                state_build_ms,
                total_profile_ms,
                use_vision,
                use_dom,
                use_ui_tree,
                use_annotation,
                display_indices,
            )
        # Log the time taken to capture the state
        end_time = time()
        logger.info(f"Desktop State capture took {end_time - start_time:.2f} seconds")
        return self.desktop_state

    def get_window_status(self, control: uia.Control) -> Status:
        if uia.IsIconic(control.NativeWindowHandle):
            return Status.MINIMIZED
        elif uia.IsZoomed(control.NativeWindowHandle):
            return Status.MAXIMIZED
        elif uia.IsWindowVisible(control.NativeWindowHandle):
            return Status.NORMAL
        else:
            return Status.HIDDEN

    def get_cursor_location(self) -> tuple[int, int]:
        return uia.GetCursorPos()

    def get_apps_from_start_menu(self) -> dict[str, str]:
        """Get installed apps. Tries Get-StartApps first, falls back to shortcut scanning."""
        command = "Get-StartApps | ConvertTo-Csv -NoTypeInformation"
        apps_info, status = PowerShellExecutor.execute_command(command)

        apps: dict[str, str] = {}
        if status == 0 and apps_info and apps_info.strip():
            try:
                reader = csv.DictReader(io.StringIO(apps_info.strip()))
                apps = {
                    row.get("Name", "").lower(): row.get("AppID", "")
                    for row in reader
                    if row.get("Name") and row.get("AppID")
                }
            except Exception as e:
                logger.warning(f"Error parsing Get-StartApps output: {e}")

        if not apps:
            # Fallback: scan Start Menu shortcut folders (works on all Windows versions)
            logger.info("Get-StartApps unavailable, falling back to Start Menu folder scan")
            apps = self._get_apps_from_shortcuts()

        # AppsFolder supplies the display name rendered for the current Windows locale.
        for name, appid in self._get_apps_folder_display_names().items():
            apps.setdefault(name, appid)
        return apps

    def _get_apps_folder_display_names(self) -> dict[str, str]:
        """Return localized Start Menu display names mapped to AppUserModelIDs."""
        command = (
            "(New-Object -ComObject Shell.Application)."
            "NameSpace('shell:::{4234d49b-0245-4df3-b780-3893943456e1}').Items() "
            "| Select-Object Name,@{n='AppID';e={$_.Path}} | ConvertTo-Csv -NoTypeInformation"
        )
        apps_info, status = PowerShellExecutor.execute_command(command)

        if status == 0 and apps_info and apps_info.strip():
            try:
                reader = csv.DictReader(io.StringIO(apps_info.strip()))
                return {
                    row.get("Name", "").lower(): row.get("AppID", "")
                    for row in reader
                    if row.get("Name") and row.get("AppID")
                }
            except Exception as e:
                logger.warning(f"Error parsing AppsFolder display names: {e}")
        return {}

    def _get_apps_from_shortcuts(self) -> dict[str, str]:
        """Scan Start Menu folders for .lnk shortcuts as a fallback for Get-StartApps."""
        import glob

        apps = {}
        start_menu_paths = [
            os.path.join(
                os.environ.get("PROGRAMDATA", r"C:\ProgramData"),
                r"Microsoft\Windows\Start Menu\Programs",
            ),
            os.path.join(
                os.environ.get("APPDATA", ""),
                r"Microsoft\Windows\Start Menu\Programs",
            ),
        ]
        for base_path in start_menu_paths:
            if not os.path.isdir(base_path):
                continue
            for lnk_path in glob.glob(os.path.join(base_path, "**", "*.lnk"), recursive=True):
                name = os.path.splitext(os.path.basename(lnk_path))[0].lower()
                if name and name not in apps:
                    apps[name] = lnk_path
        return apps

    def execute_command(
        self, command: str, timeout: int = 10, shell: str | None = None
    ) -> tuple[str, int]:
        return PowerShellExecutor.execute_command(command, timeout, shell)

    def is_window_browser(self, node: uia.Control):
        """Give any node of the app and it will return True if the app is a browser, False otherwise."""
        try:
            process = Process(node.ProcessId)
            return Browser.has_process(process.name())
        except Exception:
            return False

    def _find_window_by_name(
        self, name: str, refresh_state: bool = False
    ) -> tuple["Window | None", str]:
        """Find a window by fuzzy name match. Returns (window, error_msg).
        If the returned window is None, error_msg describes the failure reason.

        If refresh_state is True, always list the windows again before searching;
        otherwise do so only when desktop_state is absent or empty.
        """
        if refresh_state or self.desktop_state is None or not self.desktop_state.windows:
            # Matching a title needs only the top-level windows. get_state() would also walk
            # the UI tree of every window, and one app that does not answer a UIA request
            # can hold that walk for minutes (#577).
            window_list, _ = self.get_windows()
        else:
            window_list = [
                w
                for w in [self.desktop_state.active_window] + (self.desktop_state.windows or [])
                if w is not None
            ]
        if not window_list:
            return None, "No windows found on the desktop."

        windows = {window.name: window for window in window_list}
        matched_window = process.extractOne(name, list(windows.keys()), score_cutoff=70)
        if matched_window is None:
            return None, f"Application {name.title()} not found."
        window_name, _ = matched_window
        return windows.get(window_name), ""

    def resize_app(
        self, name: str | None = None, size: tuple[int, int] = None, loc: tuple[int, int] = None
    ) -> tuple[str, int]:
        if name is not None:
            target_window, error = self._find_window_by_name(name, refresh_state=True)
            if target_window is None:
                return error, 1
        else:
            # If no name provided, try to resize the active window
            target_window = self.desktop_state.active_window if self.desktop_state else None

            if target_window is None:
                return "No active window found", 1

        # target_window is guaranteed to be non-None here
        if target_window.status == Status.MINIMIZED:
            return f"{target_window.name} is minimized", 1
        elif target_window.status == Status.MAXIMIZED:
            return f"{target_window.name} is maximized", 1
        else:
            window_control = uia.ControlFromHandle(target_window.handle)
            if loc is None:
                x = window_control.BoundingRectangle.left
                y = window_control.BoundingRectangle.top
                loc = (x, y)
            if size is None:
                width = window_control.BoundingRectangle.width()
                height = window_control.BoundingRectangle.height()
                size = (width, height)
            x, y = loc
            width, height = size
            window_control.MoveWindow(x, y, width, height)
            return (f"{target_window.name} resized to {width}x{height} at {x},{y}.", 0)

    def app(
        self,
        mode: Literal["launch", "switch", "resize"],
        name: str | None = None,
        loc: tuple[int, int] | None = None,
        size: tuple[int, int] | None = None,
    ):
        match mode:
            case "launch":
                response, status, pid = self.launch_app(name)
                if status != 0:
                    return response

                # Smart wait using UIA Exists (avoids manual Python loops)
                launched = False
                if pid > 0:
                    if uia.WindowControl(ProcessId=pid).Exists(maxSearchSeconds=10):
                        launched = True

                if not launched:
                    # Fallback: Regex search for the window title
                    safe_name = re.escape(name)
                    if uia.WindowControl(RegexName=f"(?i).*{safe_name}.*").Exists(
                        maxSearchSeconds=10
                    ):
                        launched = True

                if launched:
                    return f"{name.title()} launched."
                return f"Launching {name.title()} sent, but window not detected yet."
            case "resize":
                response, status = self.resize_app(name=name, size=size, loc=loc)
                if status != 0:
                    return response
                else:
                    return response
            case "switch":
                response, status = self.switch_app(name)
                if status != 0:
                    raise ValueError(response)
                else:
                    return response

    def _check_app_exists(self, app_id: str) -> bool:
        """Check if an app with the given AppID exists in shell:AppsFolder."""
        safe_app_id = ps_quote(app_id)
        command = (
            f"$folder = (New-Object -ComObject Shell.Application).NameSpace('shell:AppsFolder'); "
            f"if ($folder) {{ [bool]$folder.ParseName({safe_app_id}) }} else {{ $false }}"
        )
        response, status = PowerShellExecutor.execute_command(command)
        return status == 0 and response.strip().lower() == "true"

    def launch_app(self, name: str) -> tuple[str, int, int]:
        apps_map = self.get_apps_from_start_menu()
        matched_app = process.extractOne(name, apps_map.keys(), score_cutoff=70)
        if matched_app is None:
            return (f"{name.title()} not found in start menu.", 1, 0)
        app_name, _ = matched_app
        appid = apps_map.get(app_name)
        if appid is None:
            return (f"{name.title()} not found in start menu.", 1, 0)

        pid = 0
        if os.path.exists(appid) or "\\" in appid:
            exe_path = resolve_known_folder_guid_path(appid)
            safe_exe_path = ps_quote(exe_path)
            command = f"Start-Process {safe_exe_path} -PassThru | Select-Object -ExpandProperty Id"
            response, status = PowerShellExecutor.execute_command(command)
            if status == 0 and response.strip().isdigit():
                pid = int(response.strip())
        else:
            if not self._check_app_exists(appid):
                return (f"Invalid app identifier: {appid}", 1, 0)

            safe = ps_quote(f"shell:AppsFolder\\{appid}")
            command = f"Start-Process {safe}"
            response, status = PowerShellExecutor.execute_command(command)

        return response, status, pid

    def switch_app(self, name: str):
        try:
            # Match against the windows open now, as resize does. The last capture's list misses
            # windows opened or reopened since, and everything outside a display/region capture.
            window, error = self._find_window_by_name(name, refresh_state=True)
            if window is None:
                return error, 1

            target_handle = window.handle

            was_minimized = uia.IsIconic(target_handle)
            self.bring_window_to_top(target_handle)
            # Windows can deny activation without raising; verify the foreground HWND.
            deadline = perf_counter() + 1.0
            while win32gui.GetForegroundWindow() != target_handle:
                if perf_counter() >= deadline:
                    return (
                        f"Failed to bring {window.name} to the foreground within 1 second.",
                        1,
                    )
                sleep(0.05)
            if was_minimized:
                content = f"Restored {window.name.title()} from minimized and switched to it."
            else:
                content = f"Switched to {window.name.title()} window."
            return content, 0
        except Exception as e:
            return (f"Error switching app: {str(e)}", 1)

    def bring_window_to_top(self, target_handle: int):
        if not win32gui.IsWindow(target_handle):
            raise ValueError("Invalid window handle")

        try:
            if win32gui.IsIconic(target_handle):
                win32gui.ShowWindow(target_handle, win32con.SW_RESTORE)

            foreground_handle = win32gui.GetForegroundWindow()

            # Validate both handles before proceeding
            if not win32gui.IsWindow(foreground_handle):
                # No valid foreground window, just try to set target as foreground
                win32gui.SetForegroundWindow(target_handle)
                win32gui.BringWindowToTop(target_handle)
                return

            # We attach our own thread (current_tid) to both the foreground and
            # target window threads to make focus change succeed.
            #
            # Simply attaching foreground_thread to target_thread is not sufficient:
            # SetForegroundWindow is called from our MCP thread, and Windows requires
            # the calling process to satisfy the "received the last input event"
            # criterion. Without attaching current_tid, the system may only bring the
            # target window to the front but refuse to transfer keyboard
            # focus, causing subsequent keyboard input to remain in the previous window.
            #
            # By attaching current_tid to both threads, our thread shares
            # their input state and inherits that eligibility, allowing the system to
            # grant the focus switch.
            foreground_thread, _ = win32process.GetWindowThreadProcessId(foreground_handle)
            target_thread, _ = win32process.GetWindowThreadProcessId(target_handle)
            current_tid = ctypes.windll.kernel32.GetCurrentThreadId()

            if not foreground_thread or not target_thread or foreground_thread == target_thread:
                win32gui.SetForegroundWindow(target_handle)
                win32gui.BringWindowToTop(target_handle)
                return

            ctypes.windll.user32.AllowSetForegroundWindow(-1)

            attached_threads = []
            try:
                for thread in (foreground_thread, target_thread):
                    if thread and thread != current_tid:
                        try:
                            win32process.AttachThreadInput(current_tid, thread, True)
                            attached_threads.append(thread)
                        except Exception as e:
                            # AttachThreadInput fails with Access Denied for elevated
                            # processes (e.g. Settings, Task Manager). Skip the attach
                            # and still attempt SetForegroundWindow below.
                            logger.debug(
                                f"AttachThreadInput failed for thread {thread} "
                                f"(likely elevated process), skipping: {e}"
                            )

                win32gui.SetForegroundWindow(target_handle)
                win32gui.BringWindowToTop(target_handle)

                win32gui.SetWindowPos(
                    target_handle,
                    win32con.HWND_TOP,
                    0,
                    0,
                    0,
                    0,
                    win32con.SWP_NOMOVE | win32con.SWP_NOSIZE | win32con.SWP_SHOWWINDOW,
                )

            finally:
                for tid in reversed(attached_threads):
                    win32process.AttachThreadInput(current_tid, tid, False)

        except Exception as e:
            logger.exception(f"Failed to bring window to top: {e}")

    def get_coordinates_from_label(self, label: int) -> tuple[int, int]:
        tree_state = self.desktop_state.tree_state
        if label < 0:
            raise IndexError(f"Label {label} out of range")
        if label < len(tree_state.interactive_nodes):
            element_node = tree_state.interactive_nodes[label]
        else:
            scroll_idx = label - len(tree_state.interactive_nodes)
            if scroll_idx < len(tree_state.scrollable_nodes):
                element_node = tree_state.scrollable_nodes[scroll_idx]
            else:
                raise IndexError(f"Label {label} out of range")
        return element_node.center.x, element_node.center.y

    def get_coordinates_from_labels(self, labels: list[int]) -> list[tuple[int, int]]:
        """Resolve multiple UI element labels to screen coordinates in bulk."""
        tree_state = self.desktop_state.tree_state
        interactive_nodes = tree_state.interactive_nodes
        scrollable_nodes = tree_state.scrollable_nodes
        interactive_len = len(interactive_nodes)

        results = []
        for label in labels:
            if label < 0:
                raise IndexError(f"Label {label} out of range")
            if label < interactive_len:
                element_node = interactive_nodes[label]
            else:
                scroll_idx = label - interactive_len
                if scroll_idx < len(scrollable_nodes):
                    element_node = scrollable_nodes[scroll_idx]
                else:
                    raise IndexError(f"Label {label} out of range")
            results.append((element_node.center.x, element_node.center.y))
        return results

    @staticmethod
    def _validate_screen_point(x: int, y: int) -> None:
        """Reject a point no window can receive input at.

        SetCursorPos and absolute mouse events both clamp an out-of-range
        point to the nearest reachable pixel, so input aimed past the edge of
        the desktop lands somewhere else entirely while the tool still reports
        success. Bounds come from the virtual desktop rather than the primary
        monitor, so a secondary monitor left of or above the primary one keeps
        its legitimate negative coordinates.

        Raises:
            ValueError: If (x, y) falls outside the virtual desktop.
        """
        left, top, width, height = uia.GetVirtualScreenRect()
        right = left + width - 1
        bottom = top + height - 1
        if not (left <= x <= right and top <= y <= bottom):
            raise ValueError(
                f"Coordinates ({x},{y}) are outside the desktop bounds "
                f"x={left}..{right}, y={top}..{bottom}"
            )

    @staticmethod
    def _modal_dialog_warning(x: int, y: int) -> str:
        """Name the modal dialog that would swallow a click at (x, y), if any (#557)."""
        try:
            root = win32gui.GetAncestor(win32gui.WindowFromPoint((x, y)), win32con.GA_ROOT)
            if not root or win32gui.IsWindowEnabled(root):
                return ""
            popup = win32gui.GetWindow(root, win32con.GW_ENABLEDPOPUP)
            title = win32gui.GetWindowText(popup) if popup != root else ""
            dialog = f"the modal dialog '{title}'" if title else "an open modal dialog"
            return f"Warning: the window there is disabled by {dialog}, so the click went nowhere."
        except Exception:
            return ""

    def click(self, loc: tuple[int, int] | list[int], button: str = "left", clicks: int = 1) -> str:
        owner = get_controller()
        owner.checkpoint_current()
        if isinstance(loc, list):
            x, y = loc[0], loc[1]
        else:
            x, y = loc
        self._validate_screen_point(x, y)
        if clicks == 0:
            owner.checkpoint_current()
            uia.SetCursorPos(x, y)
            return ""
        # Ask before clicking: a click that opens its own dialog must not look blocked.
        blocked = self._modal_dialog_warning(x, y)
        control_overlay.ripple(x, y)
        match button:
            case "left":
                if clicks >= 2:
                    dbl_wait = uia.GetDoubleClickTime() / 2000.0
                    for i in range(clicks):
                        owner.checkpoint_current()
                        uia.Click(x, y, waitTime=dbl_wait if i < clicks - 1 else 0.5)
                        owner.record_step_current()
                else:
                    owner.checkpoint_current()
                    uia.Click(x, y)
                    owner.record_step_current()
            case "right":
                for _ in range(clicks):
                    owner.checkpoint_current()
                    uia.RightClick(x, y)
                    owner.record_step_current()
            case "middle":
                for _ in range(clicks):
                    owner.checkpoint_current()
                    uia.MiddleClick(x, y)
                    owner.record_step_current()
        return blocked

    # --- 本地补丁（0.8.9+p2）：按名字/文本定位交互元素 ---------------------------
    # 复用 UIA 的交互元素（它们带坐标），所以不需要 CDP、不需要截图猜位置。
    # 为什么不是 CSS selector：Chrome 136 起禁止对默认 user-data-dir 开调试端口，
    # 要走 CDP 就得换用户数据目录（登录态全丢），代价远大于收益。
    def find_elements(
        self,
        query: str,
        *,
        regex: bool = False,
        exact: bool = False,
        window: str | None = None,
        limit: int = 20,
    ) -> list[TreeElementNode]:
        """Interactive elements whose name matches *query* (substring by default)."""
        needles = query.casefold().strip()
        pattern = None
        if regex:
            try:
                pattern = re.compile(query, re.IGNORECASE)
            except re.error as exc:
                raise ValueError(f"query 不是合法的正则表达式：{query}（{exc}）") from exc
        state = self.get_state(
            use_vision=False,
            use_ui_tree=True,
            use_dom=False,
            use_annotation=False,
            window_filter=window,
        )
        matches: list[TreeElementNode] = []
        for node in state.tree_state.interactive_nodes:
            name = (node.name or "").strip()
            if not name:
                continue
            if pattern is not None:
                hit = bool(pattern.search(name))
            elif exact:
                hit = name.casefold() == needles
            else:
                hit = bool(needles) and needles in name.casefold()
            if hit:
                matches.append(node)
                if len(matches) >= limit:
                    break
        return matches

    def activate_element(self, node: TreeElementNode) -> str:
        """Click an element's center; click twice when it sits in a non-active window.

        The first click on an inactive window only brings it forward — Windows does
        not deliver it to the control. A single synthesized click would therefore
        look like "nothing happened", which is worse than an extra click.
        """
        x, y = int(node.center.x), int(node.center.y)
        active = self.get_active_window()
        active_name = active.name if active is not None else ""
        needs_activation = bool(node.window_name) and node.window_name != active_name
        self.click((x, y), button="left", clicks=1)
        if needs_activation:
            sleep(0.35)
            self.click((x, y), button="left", clicks=1)
        return f"clicked {node.name!r} at ({x},{y})" + (
            " (window activated first)" if needs_activation else ""
        )

    # Strings longer than this typed via clipboard paste instead of
    # per-key SendKeys. SendKeys at high cadence loses keystrokes on
    # slower / loaded systems (Win11 VMs in particular) — observed
    # "hello from windows-mcp drive test" rendering as
    # "hello tttttttttttttttttttttttttt" on a 4-core Win11 VM. The
    # paste path is reliable because it bypasses the scan-code queue
    # entirely. Plain-text only; control chars route through SendKeys
    # so escape sequences ({Enter}, {Tab}, …) still work.
    _LONG_TEXT_PASTE_THRESHOLD = 20

    def type(
        self,
        loc: tuple[int, int],
        text: str,
        caret_position: Literal["start", "idle", "end"] = "idle",
        clear: bool | str = False,
        press_enter: bool | str = False,
    ) -> str:
        """Click a field, optionally empty it, type the text and report what landed.

        Returns a short note for the tool's answer: how the field was cleared and
        what it reads back, when the focused element exposes its text.
        """
        clear = as_bool(clear, "clear")
        press_enter = as_bool(press_enter, "press_enter")
        owner = get_controller()
        owner.checkpoint_current()
        x, y = loc
        self._validate_screen_point(x, y)
        uia.Click(x, y)
        owner.record_step_current()
        # --- 本地补丁（0.8.9+p2）：点击后把「怎么输」交给共用的 _type_into ---------
        # 传点击位置处的焦点元素：只有它是多行框时 Home/End 才需要 Ctrl 前缀。
        return self._type_into(
            text,
            caret_position=caret_position,
            clear=clear,
            press_enter=press_enter,
            field=self._focused_element_at(x, y),
        )

    def type_focused(
        self,
        text: str,
        caret_position: Literal["start", "idle", "end"] = "idle",
        clear: bool | str = False,
        press_enter: bool | str = False,
    ) -> str:
        """Type into whatever already has keyboard focus, without clicking.

        For "the field is already focused" cases: an address bar reached with
        Ctrl+L, a search box the previous action focused, a dialog that took focus
        on open. Avoids the clipboard round-trip that would otherwise be needed
        (and would clobber the user's clipboard).
        """
        clear = as_bool(clear, "clear")
        press_enter = as_bool(press_enter, "press_enter")
        return self._type_into(
            text,
            caret_position=caret_position,
            clear=clear,
            press_enter=press_enter,
            field=self._focused_control(),
        )

    def _type_into(
        self,
        text: str,
        *,
        caret_position: Literal["start", "idle", "end"] = "idle",
        clear: bool = False,
        press_enter: bool = False,
        field: object | None = None,
    ) -> str:
        """The typing half of type(): caret placement, clearing, input, read-back."""
        owner = get_controller()
        if caret_position in ("start", "end"):
            key = "{Home}" if caret_position == "start" else "{End}"
            # In a multi-line field Home and End stop at the ends of the caret's
            # line; Ctrl+Home and Ctrl+End reach the start and end of the text.
            # Ctrl+End means something else in a grid or list, so only use it
            # once the element that owns the caret is a multi-line edit box.
            if field is not None and self._is_multiline(field):
                key = "{Ctrl}" + key
            owner.checkpoint_current()
            uia.SendKeys(key, waitTime=0.05)
            owner.record_step_current()
        notes: list[str] = []
        target = None
        if clear:
            sleep(0.5)
            target = self._focused_control()
            notes.append(self._clear_field(target))
        # Per-key SendKeys for short text (so escape sequences keep working);
        # clipboard paste for long text (so the scan-code queue can't race).
        has_control_chars = any(c in text for c in ("\n", "\t", "{", "}"))
        if len(text) >= self._LONG_TEXT_PASTE_THRESHOLD and not has_control_chars:
            self._paste_text(text)
        else:
            # Bump interval from 0.02 → 0.04. Keeps short-text speed acceptable
            # while reducing key-loss; each character is a cancellation point.
            for ch in text:
                owner.checkpoint_current()
                uia.SendKeys(_escape_text_for_sendkeys(ch), interval=0.04, waitTime=0.05)
                owner.record_step_current()
        if clear or text:
            notes.append(self._read_back(target, text, clear, has_control_chars))
        if press_enter:
            owner.checkpoint_current()
            uia.SendKeys("{Enter}", waitTime=0.05)
            owner.record_step_current()
        return " ".join(note for note in notes if note)

    # Win32 Edit styles (WinUser.h) used to tell multi-line and password fields apart.
    _ES_MULTILINE = 0x0004
    _ES_PASSWORD = 0x0020
    _READ_BACK_LIMIT = 200

    @staticmethod
    def _focused_control():
        """The element with keyboard focus, or None when UIA cannot say."""
        try:
            return uia.GetFocusedControl()
        except Exception:
            return None

    # How long a click may take to move keyboard focus before Type stops
    # waiting to learn which element it reached.
    _FOCUS_SETTLE_SECONDS = 0.5

    def _focused_element_at(self, x: int, y: int) -> "uia.Control | None":
        """The focused element once it is the element at (x, y), else None.

        UIA can still report the element focused before the click. That may be
        a document that contains the point (a whole web page) while the click
        went to a grid inside it.
        """
        try:
            clicked = uia.ControlFromPoint(x, y)
        except Exception:
            return None
        if clicked is None:
            return None
        deadline = perf_counter() + self._FOCUS_SETTLE_SECONDS
        while True:
            focused = self._focused_control()
            try:
                if focused is not None and uia.ControlsAreSame(focused, clicked):
                    return focused
            except Exception:
                return None
            if perf_counter() >= deadline:
                return None
            sleep(0.05)

    @staticmethod
    def _describe(control) -> str:
        try:
            kind = control.ControlTypeName
            name = control.Name
        except Exception:
            return "an unknown element"
        return f"{kind} '{name[:40]}'" if name else kind

    def _edit_style(self, control) -> int | None:
        """Window style of a native Win32 Edit (any class name containing 'Edit'), else None."""
        try:
            handle = control.NativeWindowHandle
            class_name = control.ClassName
        except Exception:
            return None
        if not handle or "edit" not in (class_name or "").lower():
            return None
        try:
            return uia.GetWindowLong(handle, win32con.GWL_STYLE)
        except Exception:
            return None

    def _is_password(self, control) -> bool:
        try:
            if control.IsPassword:
                return True
        except Exception:
            pass
        style = self._edit_style(control)
        return bool(style is not None and style & self._ES_PASSWORD)

    def _is_multiline(self, control) -> bool:
        try:
            if control.ControlType == uia.ControlType.DocumentControl:
                return True
        except Exception:
            pass
        style = self._edit_style(control)
        return bool(style is not None and style & self._ES_MULTILINE)

    def _is_text_field(self, control) -> bool:
        """Whether the element takes text: an edit, a document, or anything with a writable value."""
        try:
            if control.ControlType in (
                uia.ControlType.EditControl,
                uia.ControlType.DocumentControl,
            ):
                return True
        except Exception:
            pass
        if self._edit_style(control) is not None:
            return True
        try:
            pattern = control.GetPattern(uia.PatternId.ValuePattern)
            return pattern is not None and not pattern.IsReadOnly
        except Exception:
            return False

    def _read_value(self, control) -> str | None:
        """The field's text through UIA ValuePattern, else WM_GETTEXT for a native Edit."""
        if control is None or self._is_password(control):
            return None
        try:
            pattern = control.GetPattern(uia.PatternId.ValuePattern)
            if pattern is not None:
                return pattern.Value
        except Exception:
            pass
        if self._edit_style(control) is not None:
            try:
                return uia.GetEditText(control.NativeWindowHandle)
            except Exception:
                return None
        return None

    def _clear_field(self, control) -> str:
        """Empty the focused field without Ctrl+A.

        Ctrl+A is an application shortcut in many programs (in list views it often
        means "mark every record"), so it is never sent. The caret goes to the start,
        Shift+End (Ctrl+Shift+End for multi-line fields) selects to the end, and
        Backspace deletes the selection. If the field still holds text afterwards and
        exposes a writable UIA ValuePattern, the value is set to "" directly.
        """
        owner = get_controller()
        if control is not None and not self._is_text_field(control):
            # Home, Shift+End and Backspace would move or extend a selection in a grid
            # or list and might delete from whatever the app routes them to.
            return (
                f"Warning: did not clear: the focused element is {self._describe(control)},"
                " not a text field. The text was typed there; check where it landed."
            )
        if control is not None and self._is_multiline(control):
            keys = ("{Ctrl}{Home}", "{Ctrl}{Shift}{End}", "{Back}")
            how = "Ctrl+Home, Ctrl+Shift+End, Backspace"
        else:
            keys = ("{Home}", "{Shift}{End}", "{Back}")
            how = "Home, Shift+End, Backspace"
        for key in keys:
            owner.checkpoint_current()
            uia.SendKeys(key, waitTime=0.05)
            owner.record_step_current()
        if control is None:
            return f"Cleared with {how} (focused element unknown)."
        remaining = self._read_value(control)
        if remaining:
            try:
                pattern = control.GetPattern(uia.PatternId.ValuePattern)
                if pattern is not None and not pattern.IsReadOnly:
                    owner.checkpoint_current()
                    pattern.SetValue("", waitTime=0.05)
                    owner.record_step_current()
                    remaining = self._read_value(control)
                    how += ", then UIA ValuePattern"
            except Exception:
                pass
        if remaining:
            return f"Warning: {self._describe(control)} still held text after clearing ({how})."
        return f"Cleared {self._describe(control)} with {how}."

    def _read_back(self, control, text: str, clear: bool, has_control_chars: bool) -> str:
        """Say what the field holds after typing, and whether focus moved away.

        control is the element focused before typing (known only after a clear, which
        waits for focus to settle); without it the element focused now is read.
        """
        now = self._focused_control()
        if control is None:
            control = now
            if control is None:
                return ""
        elif now is not None:
            try:
                moved = not uia.ControlsAreSame(control, now)
            except Exception:
                moved = False
            if moved:
                return (
                    f"Warning: focus moved to {self._describe(now)} while typing;"
                    " some keystrokes may have gone there."
                )
        if self._is_password(control) or (not clear and self._is_multiline(control)):
            return ""
        value = self._read_value(control)
        if value is None:
            if clear or self._is_text_field(control):
                return ""
            return (
                f"Could not read the text back: the focused element is {self._describe(control)}."
            )
        limit = self._READ_BACK_LIMIT
        shown = value if len(value) <= limit else value[:limit] + "…"
        if has_control_chars:
            return f"Field reads back '{shown}'."
        if (clear and value != text) or (not clear and text not in value):
            return f"Warning: the field reads back '{shown}', not the typed text."
        return f"Field reads back '{shown}'."

    def _paste_text(self, text: str):
        """Stash text on the clipboard, Ctrl+V, restore prior clipboard.
        Plain-text only — control chars (newlines, tabs, braces) need to
        route through SendKeys instead so escape sequences are honored.

        The prior clipboard is restored in every format held in memory, not
        just as text: an image or files copied in Explorer read as "" through
        GetClipboardText, so the user's clipboard was left holding empty text.
        """
        prior = None
        owner = get_controller()
        owner.checkpoint_current()
        try:
            prior = uia.GetClipboardSnapshot()
        except Exception:
            pass
        uia.SetClipboardText(text)
        # Tiny pause so the OS clipboard write settles before Ctrl+V reads.
        sleep(0.05)
        try:
            owner.checkpoint_current()
            uia.SendKeys("{Ctrl}v", waitTime=0.05)
            owner.record_step_current()
        finally:
            # Do not overwrite a clipboard value changed by the user.
            if prior is not None:
                try:
                    if uia.GetClipboardText() == text:
                        uia.SetClipboardSnapshot(prior)
                except Exception:
                    pass

    def scroll(
        self,
        loc: tuple[int, int] = None,
        type: Literal["horizontal", "vertical"] = "vertical",
        direction: Literal["up", "down", "left", "right"] = "down",
        wheel_times: int = 1,
    ) -> None:
        owner = get_controller()
        owner.checkpoint_current()
        # Check the request before the pointer moves. A direction that does not
        # fit the type was answered with a successful reply after hovering loc,
        # and a count below 1 hovered loc without scrolling.
        directions = {"vertical": ("up", "down"), "horizontal": ("left", "right")}
        if type not in directions:
            raise ValueError('Invalid type. Use "horizontal" or "vertical".')
        if direction not in directions[type]:
            first, second = directions[type]
            raise ValueError(f'Invalid direction. Use "{first}" or "{second}".')
        if wheel_times < 1:
            raise ValueError("wheel_times must be 1 or more")
        if loc:
            self.move(loc)
        match type:
            case "vertical":
                match direction:
                    case "up":
                        for _ in range(wheel_times):
                            owner.checkpoint_current()
                            uia.WheelUp(1)
                            owner.record_step_current()
                    case "down":
                        for _ in range(wheel_times):
                            owner.checkpoint_current()
                            uia.WheelDown(1)
                            owner.record_step_current()
            case "horizontal":
                match direction:
                    case "left":
                        try:
                            owner.input_ledger.press(
                                "key:shift",
                                lambda: uia.PressKey(uia.Keys.VK_SHIFT, waitTime=0.05),
                                lambda: uia.ReleaseKey(uia.Keys.VK_SHIFT, waitTime=0.05),
                                lambda: owner.physical_key_down(uia.Keys.VK_SHIFT),
                            )
                            for _ in range(wheel_times):
                                owner.checkpoint_current()
                                uia.WheelUp(1)
                                owner.record_step_current()
                        finally:
                            owner.input_ledger.release("key:shift")
                    case "right":
                        try:
                            owner.input_ledger.press(
                                "key:shift",
                                lambda: uia.PressKey(uia.Keys.VK_SHIFT, waitTime=0.05),
                                lambda: uia.ReleaseKey(uia.Keys.VK_SHIFT, waitTime=0.05),
                                lambda: owner.physical_key_down(uia.Keys.VK_SHIFT),
                            )
                            for _ in range(wheel_times):
                                owner.checkpoint_current()
                                uia.WheelDown(1)
                                owner.record_step_current()
                        finally:
                            owner.input_ledger.release("key:shift")

    def _normalize_drag_duration(self, duration: float | int | str | None) -> float | None:
        if duration is None:
            return None
        if isinstance(duration, bool):
            raise ValueError("duration must be a finite number of seconds")
        try:
            effective_duration = float(duration)
        except (TypeError, ValueError) as exc:
            raise ValueError("duration must be a finite number of seconds") from exc
        if not math.isfinite(effective_duration):
            raise ValueError("duration must be a finite number of seconds")
        if effective_duration < 0 or effective_duration > 10:
            raise ValueError("duration must be between 0 and 10 seconds")
        return effective_duration

    @staticmethod
    def _normalize_drag_point(value: object, name: str) -> tuple[int, int]:
        if not isinstance(value, (list, tuple)) or len(value) != 2:
            raise ValueError(f"{name} must be a list or tuple of exactly 2 integers [x, y]")
        x, y = value
        if any(isinstance(item, bool) or not isinstance(item, int) for item in (x, y)):
            raise ValueError(f"{name} must contain exactly 2 integers")
        return x, y

    def drag(
        self,
        loc: tuple[int, int] | list[int],
        from_loc: tuple[int, int] | list[int] | None = None,
        duration: float | int | str | None = None,
    ) -> dict[str, object]:
        owner = get_controller()
        x, y = self._normalize_drag_point(loc, "loc")
        normalized_from_loc = (
            None if from_loc is None else self._normalize_drag_point(from_loc, "from_loc")
        )
        effective_duration = self._normalize_drag_duration(duration)
        # Check both ends before the wait and the button press: SetCursorPos would
        # clamp a point off the desktop to its edge.
        if normalized_from_loc is not None:
            self._validate_screen_point(*normalized_from_loc)
        self._validate_screen_point(x, y)
        owner.checkpoint_current()
        sleep(0.5)
        owner.checkpoint_current()
        if normalized_from_loc is None:
            cx, cy = uia.GetCursorPos()
        else:
            cx, cy = normalized_from_loc
        try:
            owner.input_ledger.press(
                "mouse:left",
                lambda: uia.PressMouse(cx, cy, waitTime=0.05),
                lambda: uia.ReleaseMouse(waitTime=0.05),
                lambda: owner.physical_mouse_down("left"),
            )
            owner.record_step_current()
            # Keep both the legacy drag and duration-based drag interruptible.
            steps = (
                max(1, min(80, max(abs(x - cx), abs(y - cy)) // 20))
                if effective_duration is None
                else max(1, min(200, math.ceil(effective_duration / 0.01)))
            )
            interval = 0.01 if effective_duration is None else effective_duration / steps
            for step in range(1, steps + 1):
                owner.checkpoint_current()
                uia.SetCursorPos(
                    cx + round((x - cx) * step / steps), cy + round((y - cy) * step / steps)
                )
                owner.record_step_current()
                if interval:
                    sleep(interval)
        finally:
            owner.input_ledger.release("mouse:left")
        return {"start": [cx, cy], "end": [x, y], "duration": effective_duration}

    def move(self, loc: tuple[int, int]):
        owner = get_controller()
        x, y = loc
        self._validate_screen_point(x, y)
        owner.checkpoint_current()
        cx, cy = uia.GetCursorPos()
        steps = max(1, min(80, max(abs(x - cx), abs(y - cy)) // 20))
        for step in range(1, steps + 1):
            owner.checkpoint_current()
            uia.SetCursorPos(cx + (x - cx) * step // steps, cy + (y - cy) * step // steps)
            owner.record_step_current()
            sleep(0.003)

    def shortcut(self, shortcut: str):
        sendkeys_str = _shortcut_to_sendkeys(shortcut)
        owner = get_controller()
        owner.checkpoint_current()
        uia.SendKeys(sendkeys_str, interval=0.01)
        owner.record_step_current()

    def multi_select(self, press_ctrl: bool | str = False, locs: list[tuple[int, int]] = []):
        owner = get_controller()
        owner.checkpoint_current()
        press_ctrl = press_ctrl is True or (
            isinstance(press_ctrl, str) and press_ctrl.lower() == "true"
        )
        # Validate every point before Ctrl goes down, so bad input fails without
        # touching the keyboard (and without clicking half of the list).
        points = [self._normalize_drag_point(loc, f"locs[{i}]") for i, loc in enumerate(locs)]
        for x, y in points:
            self._validate_screen_point(x, y)
        try:
            if press_ctrl:
                owner.input_ledger.press(
                    "key:ctrl",
                    lambda: uia.PressKey(uia.Keys.VK_CONTROL, waitTime=0.05),
                    lambda: uia.ReleaseKey(uia.Keys.VK_CONTROL, waitTime=0.05),
                    lambda: owner.physical_key_down(uia.Keys.VK_CONTROL),
                )
            for x, y in points:
                owner.checkpoint_current()
                uia.Click(x, y, waitTime=0.2)
                owner.record_step_current()
                sleep(0.5)
        finally:
            if press_ctrl:
                owner.input_ledger.release("key:ctrl")

    def multi_edit(self, locs: list[tuple[int, int, str]]) -> list[str]:
        # Check every point first. Type checks its own point too, but only after
        # the fields before it have been cleared and retyped.
        for x, y, _ in locs:
            self._validate_screen_point(x, y)
        notes = []
        for loc in locs:
            get_controller().checkpoint_current()
            x, y, text = loc
            note = self.type((x, y), text=text, clear=True)
            notes.append(note.replace("Warning:", f"Warning at ({x},{y}):"))
        return notes

    def scrape(self, url: str) -> str:
        current_url = url
        try:
            for _ in range(5):
                response = safe_get(current_url, timeout=10)
                if not response.is_redirect:
                    break
                current_url = urljoin(current_url, response.headers["Location"])
            else:
                raise ValueError("Too many redirects while fetching URL")
            response.raise_for_status()
        except requests.exceptions.HTTPError as e:
            raise ValueError(f"HTTP error for {current_url}: {e}") from e
        except requests.exceptions.ConnectionError as e:
            raise ConnectionError(f"Failed to connect to {current_url}: {e}") from e
        except requests.exceptions.Timeout as e:
            raise TimeoutError(f"Request timed out for {current_url}: {e}") from e
        has_charset = "charset" in response.headers.get("content-type", "").lower()
        if not has_charset and response.encoding == "ISO-8859-1":
            # requests assumes ISO-8859-1 for ``text/*`` without a charset
            # (RFC 2616) and ignores the in-document ``<meta charset>``, so
            # non-ASCII pages come back as mojibake. Sniff the body instead.
            response.encoding = response.apparent_encoding or "utf-8"
        # markdownify reads any other body as one HTML text node: it collapses
        # line breaks and indentation and escapes "_" and "*", which mangles
        # JSON, source files and plain text. A missing type keeps the old path.
        media_type = response.headers.get("content-type", "").split(";")[0].strip().lower()
        if media_type and media_type not in _HTML_MEDIA_TYPES:
            return response.text
        return markdownify(html=response.text)

    def is_overlay_window(self, element: uia.Control) -> bool:
        """Return True if the window is a decorative overlay rather than a real app window.

        "No children" alone is deliberately not enough. When UIA child
        enumeration degrades — as it does on Windows ARM64 under x86-emulated
        Python — every window looks childless, and treating that as an overlay
        filters out the entire desktop and leaves the caller blind. A real app
        window always has a title, so require both signals.
        """
        name = element.Name.strip()
        if "Overlay" in name:
            return True
        return not name and len(element.GetChildren()) == 0

    def get_controls_handles(self, optimized: bool = False) -> list[int]:
        handles = []
        own_pid = os.getpid()

        def owned_by_this_server(hwnd) -> bool:
            # The control overlay (7 WindowsMCPControl_* windows) and the click flashes live in this
            # process. They are never a target, and the tree walk spends about a second on each one,
            # which made every Snapshot and every after-state take ~15 s. A handle whose owner cannot
            # be read is kept, as before.
            try:
                return win32process.GetWindowThreadProcessId(hwnd)[1] == own_pid
            except Exception:
                return False

        # For even more faster results (still under development)
        def callback(hwnd, _):
            try:
                # Validate handle before checking properties
                if (
                    win32gui.IsWindow(hwnd)
                    and win32gui.IsWindowVisible(hwnd)
                    and is_window_on_current_desktop(hwnd)
                    and not owned_by_this_server(hwnd)
                ):
                    handles.append(hwnd)
            except Exception:
                # Skip invalid handles without logging (common during window enumeration)
                pass

        win32gui.EnumWindows(callback, None)

        if desktop_hwnd := win32gui.FindWindow("Progman", None):
            handles.append(desktop_hwnd)
        if taskbar_hwnd := win32gui.FindWindow("Shell_TrayWnd", None):
            handles.append(taskbar_hwnd)
        if secondary_taskbar_hwnd := win32gui.FindWindow("Shell_SecondaryTrayWnd", None):
            handles.append(secondary_taskbar_hwnd)
        # EnumWindows reports the windows in z-order (front first), and get_windows() takes the
        # position as each window's depth. The shell windows are usually reported by EnumWindows
        # too, so keep each handle at its first position only.
        return list(dict.fromkeys(handles))

    # Tuned retry envelope for transient UIA empty results. The OS
    # briefly returns NULL from GetForegroundWindow during focus
    # transitions, app launches, and notification overlays — three
    # attempts at 100 ms each covers the typical race without
    # noticeably slowing the snapshot path when state is steady.
    _UIA_RETRIES = 3
    _UIA_RETRY_SLEEP_MS = 100

    def get_active_window(self, windows: list[Window] | None = None) -> Window | None:
        """Return the foreground app window, retrying briefly on transient
        empty results.

        GetForegroundWindow can return NULL during focus transitions, app
        launches, and notification-overlay flicker — even when there is a
        visible focused window on screen. Without a retry, Snapshot
        reports "No active window found" and the caller is left blind.
        """
        last_error = None
        for attempt in range(self._UIA_RETRIES):
            try:
                if windows is None:
                    windows, _ = self.get_windows()
                active_window = self.get_foreground_window()
                if active_window is None:
                    # NULL foreground — retry, this often clears on the
                    # next pass once whatever was transitioning settles.
                    sleep(self._UIA_RETRY_SLEEP_MS / 1000.0)
                    continue
                if active_window.ClassName == "Progman":
                    return None
                active_window_handle = active_window.NativeWindowHandle
                for window in windows:
                    if window.handle != active_window_handle:
                        continue
                    return window
                # In case active window is not present in the windows list
                return Window(
                    **{
                        "name": active_window.Name,
                        "is_browser": self.is_window_browser(active_window),
                        "depth": 0,
                        "bounding_box": BoundingBox(
                            left=active_window.BoundingRectangle.left,
                            top=active_window.BoundingRectangle.top,
                            right=active_window.BoundingRectangle.right,
                            bottom=active_window.BoundingRectangle.bottom,
                            width=active_window.BoundingRectangle.width(),
                            height=active_window.BoundingRectangle.height(),
                        ),
                        "status": self.get_window_status(active_window),
                        "handle": active_window_handle,
                        "process_id": active_window.ProcessId,
                    }
                )
            except Exception as ex:
                last_error = ex
                if uia.is_timeout_exception(ex):
                    # The foreground window is not answering UI Automation; a retry
                    # would only wait out the same timeout again.
                    break
                # Same retry policy for transient exceptions —
                # ControlFromHandle(NULL) raises during focus transitions
                # and the next attempt usually succeeds.
                sleep(self._UIA_RETRY_SLEEP_MS / 1000.0)
                continue
        if last_error is not None:
            logger.error(
                f"Error in get_active_window after {attempt + 1} attempt(s): {last_error}"
            )
        return None

    def get_foreground_window(self) -> uia.Control | None:
        handle = uia.GetForegroundWindow()
        # NULL handle means no window has foreground focus right now —
        # don't pass that into ControlFromHandle, which would raise.
        if not handle:
            return None
        excluded_processes = _excluded_process_names()
        if excluded_processes:
            process_name = _window_process_name(handle)
            if process_name and process_name.casefold() in excluded_processes:
                return None
        return self.get_window_from_element_handle(handle)

    def get_window_from_element_handle(self, element_handle: int) -> uia.Control:
        current = uia.ControlFromHandle(element_handle)
        root_handle = uia.GetRootControl().NativeWindowHandle

        while True:
            parent = current.GetParentControl()
            if parent is None or parent.NativeWindowHandle == root_handle:
                return current
            current = parent

    def get_windows(
        self, controls_handles: list[int] | None = None
    ) -> tuple[list[Window], set[int]]:
        try:
            windows = []
            window_handles = set()
            if controls_handles is None:
                controls_handles = self.get_controls_handles()
            excluded_processes = _excluded_process_names()
            for depth, hwnd in enumerate(controls_handles):
                if excluded_processes:
                    process_name = _window_process_name(hwnd)
                    if process_name and process_name.casefold() in excluded_processes:
                        continue
                try:
                    child = uia.ControlFromHandle(hwnd)
                except Exception:
                    continue

                # Filter out Overlays (e.g. NVIDIA, Steam)
                if self.is_overlay_window(child):
                    continue

                if isinstance(child, (uia.WindowControl, uia.PaneControl)):
                    window_pattern = child.GetPattern(uia.PatternId.WindowPattern)
                    if window_pattern is None:
                        continue

                    if window_pattern.CanMinimize and window_pattern.CanMaximize:
                        status = self.get_window_status(child)

                        bounding_rect = child.BoundingRectangle
                        if bounding_rect.isempty() and status != Status.MINIMIZED:
                            continue

                        windows.append(
                            Window(
                                **{
                                    "name": child.Name,
                                    "depth": depth,
                                    "status": status,
                                    "bounding_box": BoundingBox(
                                        left=bounding_rect.left,
                                        top=bounding_rect.top,
                                        right=bounding_rect.right,
                                        bottom=bounding_rect.bottom,
                                        width=bounding_rect.width(),
                                        height=bounding_rect.height(),
                                    ),
                                    "handle": child.NativeWindowHandle,
                                    "process_id": child.ProcessId,
                                    "is_browser": self.is_window_browser(child),
                                }
                            )
                        )
                        window_handles.add(child.NativeWindowHandle)
        except Exception as ex:
            logger.error(f"Error in get_windows: {ex}")
            windows = []
        return windows, window_handles

    def get_screen_size(self) -> Size:
        width, height = uia.GetVirtualScreenSize()
        return Size(width=width, height=height)

    def get_screen_box(self) -> BoundingBox:
        left, top, width, height = uia.GetVirtualScreenRect()
        return BoundingBox(
            left=left,
            top=top,
            right=left + width,
            bottom=top + height,
            width=width,
            height=height,
        )

    @staticmethod
    def parse_display_selection(
        display: int | list[int] | tuple[int, ...] | None,
    ) -> list[int] | None:
        if display is None or display == "":
            return None

        if isinstance(display, bool):
            raise ValueError(
                "display must be a JSON array of zero-based active display indices, for example [0] or [0,1]"
            )

        if isinstance(display, int):
            values = [display]
        elif isinstance(display, (list, tuple)):
            values = list(display)
        else:
            raise ValueError(
                "display must be a JSON array of zero-based active display indices, for example [0] or [0,1]"
            )

        unique_values: list[int] = []
        for value in values:
            if not isinstance(value, int) or value < 0:
                raise ValueError("display must contain only zero-based active display indices")
            if value not in unique_values:
                unique_values.append(value)
        return unique_values or None

    def parse_region_selection(self, region: list[int] | tuple[int, ...] | None) -> uia.Rect | None:
        if region is None or region == "":
            return None

        if not isinstance(region, (list, tuple)) or len(region) != 4:
            raise ValueError("region must be a JSON array of 4 integers [left, top, right, bottom]")

        values = []
        for item in region:
            if isinstance(item, bool) or not isinstance(item, int):
                raise ValueError("region must contain only integers [left, top, right, bottom]")
            values.append(item)

        left, top, right, bottom = values
        if right <= left or bottom <= top:
            raise ValueError("region must satisfy right > left and bottom > top")

        candidate = uia.Rect(left, top, right, bottom)
        screen_box = self.get_screen_box()
        screen_rect = uia.Rect(screen_box.left, screen_box.top, screen_box.right, screen_box.bottom)
        overlap = candidate.intersect(screen_rect)
        if overlap.width() <= 0 or overlap.height() <= 0:
            raise ValueError(
                f"region {region} does not overlap the virtual screen bounds "
                f"{screen_box.xyxy_to_string()}"
            )

        return candidate

    @staticmethod
    def get_displays() -> list[uia.DisplayInfo]:
        return uia.GetDisplays()

    @staticmethod
    def _display_to_view(display: uia.DisplayInfo) -> Display:
        return Display(
            index=display.index,
            device_name=display.device_name,
            bounding_box=Desktop._rect_to_bounding_box(display.rect),
            primary=display.primary,
        )

    def get_display_union_rect(
        self,
        display_indices: list[int],
        displays: list[uia.DisplayInfo] | None = None,
    ) -> uia.Rect:
        displays = displays if displays is not None else self.get_displays()
        if not displays:
            logger.warning(
                "Monitor enumeration returned no monitors while display filter was requested"
            )
            raise ValueError("No displays detected")

        display_by_index = {display.index: display for display in displays}
        invalid_indices = [index for index in display_indices if index not in display_by_index]
        if invalid_indices:
            available_indices = ",".join(str(display.index) for display in displays)
            logger.warning(
                "Invalid display selection %s. Available displays: %s",
                invalid_indices,
                available_indices,
            )
            raise ValueError(
                f"Invalid display index {invalid_indices[0]}. Available displays: {available_indices}"
            )

        selected_rects = [display_by_index[index].rect for index in display_indices]
        return uia.Rect(
            left=min(rect.left for rect in selected_rects),
            top=min(rect.top for rect in selected_rects),
            right=max(rect.right for rect in selected_rects),
            bottom=max(rect.bottom for rect in selected_rects),
        )

    def get_screenshot(self, capture_rect: uia.Rect | None = None) -> Image.Image:
        # The persistent AI indicator is hidden and acknowledged before any
        # screenshot backend reads pixels. Physical input is released first so
        # a stalled capture cannot leave the user blocked by an invisible AI.
        controller = get_controller()
        capture_generation = controller.pause_for_capture()
        restored = False
        try:
            with control_overlay.suspend_for_capture():
                if not flash_overlay.cancel_active_flash():
                    raise RuntimeError("Previous screenshot flash did not close before capture")
                image, used_backend = screenshot_capture.capture(capture_rect)
                self._last_screenshot_backend = used_backend
            restored = True
        finally:
            controller.resume_after_capture(capture_generation, restored=restored)
        flash_overlay.show_capture_flash(capture_rect)
        return image

    @staticmethod
    def _draw_grid_lines(image: Image.Image, grid_lines: tuple[int, int]) -> None:
        """Divide the image into grid_lines = (columns, rows) equal cells with light gray lines."""
        draw = ImageDraw.Draw(image)
        image_width, image_height = image.size
        w_count, h_count = grid_lines
        for i in range(1, w_count):
            x = image_width * i // w_count
            draw.line([(x, 0), (x, image_height)], fill=(200, 200, 200, 128), width=1)
        for i in range(1, h_count):
            y = image_height * i // h_count
            draw.line([(0, y), (image_width, y)], fill=(200, 200, 200, 128), width=1)

    def get_annotated_screenshot(
        self,
        nodes: list[TreeElementNode],
        cursor_pos: tuple[int, int] | None = None,
        grid_lines: tuple[int, int] | None = None,
        capture_rect: uia.Rect | None = None,
    ) -> Image.Image:
        screenshot = self.get_screenshot(capture_rect=capture_rect)
        annotated_screenshot = screenshot.copy()
        draw = ImageDraw.Draw(annotated_screenshot)
        image_width, image_height = annotated_screenshot.size
        font_size = 12
        try:
            font = ImageFont.truetype("arial.ttf", font_size)
        except IOError:
            font = ImageFont.load_default()

        def get_random_color():
            return "#{:06x}".format(random.randint(0, 0xFFFFFF))

        def clamp(value: float, minimum: float, maximum: float) -> float:
            return max(minimum, min(value, maximum))

        def get_label_size(text: str) -> tuple[int, int]:
            text_box = draw.textbbox((0, 0), text, font=font)
            return text_box[2] - text_box[0] + 4, text_box[3] - text_box[1] + 4

        def draw_label(text: str, x: float, y: float, color: str) -> None:
            label_width, label_height = get_label_size(text)
            label_x = int(clamp(x, 0, max(0, image_width - label_width)))
            label_y = int(clamp(y, 0, max(0, image_height - label_height)))
            draw.rectangle(
                [(label_x, label_y), (label_x + label_width, label_y + label_height)],
                fill=color,
            )
            draw.text((label_x + 2, label_y + 2), text, fill=(255, 255, 255), font=font)

        if capture_rect:
            left_offset, top_offset = capture_rect.left, capture_rect.top
        else:
            left_offset, top_offset, _, _ = uia.GetVirtualScreenRect()

        # Draw grid lines if requested
        if grid_lines:
            self._draw_grid_lines(annotated_screenshot, grid_lines)

        def draw_annotation(label, node: TreeElementNode):
            box = node.bounding_box
            color = get_random_color()

            adjusted_left = int(box.left - left_offset)
            adjusted_top = int(box.top - top_offset)
            adjusted_right = int(box.right - left_offset)
            adjusted_bottom = int(box.bottom - top_offset)
            clipped_box = (
                int(clamp(adjusted_left, 0, image_width - 1)),
                int(clamp(adjusted_top, 0, image_height - 1)),
                int(clamp(adjusted_right, 0, image_width - 1)),
                int(clamp(adjusted_bottom, 0, image_height - 1)),
            )
            left, top, right, bottom = clipped_box
            if right <= left or bottom <= top:
                return

            draw.rectangle(clipped_box, outline=color, width=2)

            label_text = str(label)
            label_width, label_height = get_label_size(label_text)
            label_x = right - label_width
            label_y = top - label_height - 2
            if label_y < 0:
                label_y = bottom + 2
            draw_label(label_text, label_x, label_y, color)

        # Draw annotations sequentially: PIL ImageDraw is not thread-safe and
        # drawing is GIL-bound, so parallel execution adds risk without speed.
        for i, node in enumerate(nodes):
            draw_annotation(i, node)

        # Draw cursor highlight if pos provided
        if cursor_pos:
            cx, cy = cursor_pos
            acx = int(cx - left_offset)
            acy = int(cy - top_offset)

            # Draw a distinctive marker (e.g., a circle or crosshair with a box)
            r = 15
            draw.ellipse([acx - r, acy - r, acx + r, acy + r], outline="red", width=3)
            draw.line([acx - r, acy, acx + r, acy], fill="red", width=2)
            draw.line([acx, acy - r, acx, acy + r], fill="red", width=2)

            # Draw "Cursor" label
            c_label = "CURSOR"
            draw_label(c_label, acx + r, acy - r, "red")

        return annotated_screenshot

    @staticmethod
    def _rect_to_bounding_box(rect: uia.Rect | None) -> BoundingBox | None:
        if rect is None:
            return None
        return BoundingBox(
            left=rect.left,
            top=rect.top,
            right=rect.right,
            bottom=rect.bottom,
            width=rect.width(),
            height=rect.height(),
        )

    @staticmethod
    def _point_in_region(point: tuple[int, int], region: BoundingBox) -> bool:
        x, y = point
        return region.left <= x < region.right and region.top <= y < region.bottom

    @staticmethod
    def _clip_bounding_box_to_region(
        box: BoundingBox | None, region: BoundingBox
    ) -> BoundingBox | None:
        if box is None:
            return None
        left = max(box.left, region.left)
        top = max(box.top, region.top)
        right = min(box.right, region.right)
        bottom = min(box.bottom, region.bottom)
        if right <= left or bottom <= top:
            return None
        return BoundingBox(
            left=left,
            top=top,
            right=right,
            bottom=bottom,
            width=right - left,
            height=bottom - top,
        )

    def _filter_window_to_region(self, window: Window | None, region: BoundingBox) -> Window | None:
        if window is None:
            return None
        clipped_box = self._clip_bounding_box_to_region(window.bounding_box, region)
        if clipped_box is None:
            return None
        return Window(
            name=window.name,
            is_browser=window.is_browser,
            depth=window.depth,
            status=window.status,
            bounding_box=clipped_box,
            handle=window.handle,
            process_id=window.process_id,
        )

    def _filter_windows_to_region(self, windows: list[Window], region: BoundingBox) -> list[Window]:
        filtered_windows: list[Window] = []
        for window in windows:
            filtered_window = self._filter_window_to_region(window, region)
            if filtered_window is not None:
                filtered_windows.append(filtered_window)
        return filtered_windows

    def _filter_tree_node_to_region(
        self, node: TreeElementNode, region: BoundingBox
    ) -> TreeElementNode | None:
        clipped_box = self._clip_bounding_box_to_region(node.bounding_box, region)
        if clipped_box is None:
            return None
        return TreeElementNode(
            name=node.name,
            control_type=node.control_type,
            window_name=node.window_name,
            bounding_box=clipped_box,
            center=clipped_box.get_center(),
            metadata=node.metadata,
        )

    def _filter_scroll_node_to_region(self, node, region: BoundingBox):
        clipped_box = self._clip_bounding_box_to_region(node.bounding_box, region)
        if clipped_box is None:
            return None
        return node.__class__(
            name=node.name,
            control_type=node.control_type,
            window_name=node.window_name,
            bounding_box=clipped_box,
            center=clipped_box.get_center(),
            metadata=node.metadata,
        )

    def _filter_semantic_node_to_region(
        self,
        node: SemanticNode | None,
        region: BoundingBox,
    ) -> SemanticNode | None:
        if node is None:
            return None

        clipped_box = None
        if node.bounding_box is not None:
            clipped_box = self._clip_bounding_box_to_region(node.bounding_box, region)
            if clipped_box is None:
                return None

        filtered_children = []
        for child in node.children:
            filtered_child = self._filter_semantic_node_to_region(child, region)
            if filtered_child is not None:
                filtered_children.append(filtered_child)

        if node.element_type != "desktop" and clipped_box is None and not filtered_children:
            return None

        filtered_node = SemanticNode(
            control_type=node.control_type,
            element_type=node.element_type,
            name=node.name,
            window_name=node.window_name,
            center=clipped_box.get_center() if clipped_box is not None else node.center,
            bounding_box=clipped_box,
            metadata=dict(node.metadata),
        )
        filtered_node.children = filtered_children
        return filtered_node

    def _filter_tree_state_to_region(self, tree_state, region: BoundingBox):
        filtered_interactive_nodes = []
        for node in tree_state.interactive_nodes:
            filtered_node = self._filter_tree_node_to_region(node, region)
            if filtered_node is not None:
                filtered_interactive_nodes.append(filtered_node)

        filtered_scrollable_nodes = []
        for node in tree_state.scrollable_nodes:
            filtered_node = self._filter_scroll_node_to_region(node, region)
            if filtered_node is not None:
                filtered_scrollable_nodes.append(filtered_node)

        filtered_dom_node = None
        if tree_state.dom_node is not None:
            filtered_dom_node = self._filter_scroll_node_to_region(tree_state.dom_node, region)

        filtered_semantic_root = self._filter_semantic_node_to_region(
            tree_state.semantic_tree_root,
            region,
        )
        if filtered_semantic_root is not None:
            filtered_semantic_root.bounding_box = region
            filtered_semantic_root.center = region.get_center()

        return tree_state.__class__(
            status=tree_state.status,
            root_node=TreeElementNode(
                name="Desktop",
                control_type="PaneControl",
                bounding_box=region,
                center=region.get_center(),
                window_name="Desktop",
                metadata={},
            ),
            dom_node=filtered_dom_node,
            interactive_nodes=filtered_interactive_nodes,
            scrollable_nodes=filtered_scrollable_nodes,
            dom_informative_nodes=tree_state.dom_informative_nodes if filtered_dom_node else [],
            capture_sec=tree_state.capture_sec,
            semantic_tree_root=filtered_semantic_root,
            truncated=tree_state.truncated,
            element_limit=tree_state.element_limit,
        )
